---
title: Shield slash
layout: icon
categories:
  - Security
tags:
  - shield
  - badge
---
