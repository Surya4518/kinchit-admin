---
title: Sort numeric down
categories:
  - Sort and filter
tags:
  - sort
  - filter
  - organize
---
