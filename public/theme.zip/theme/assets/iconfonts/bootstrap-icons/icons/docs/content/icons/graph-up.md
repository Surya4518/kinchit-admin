---
title: Graph up
categories:
  - Data
tags:
  - chart
  - graph
  - analytics
---
