---
title: Mouse2 fill
categories:
  - Devices
tags:
  - mice
  - input
---
