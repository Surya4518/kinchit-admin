---
title: Mic mute
categories:
  - Media
tags:
  - audio
  - video
  - av
  - sound
  - input
  - microphone
---
