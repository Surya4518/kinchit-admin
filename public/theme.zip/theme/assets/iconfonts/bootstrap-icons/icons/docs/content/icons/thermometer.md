---
title: Thermometer
categories:
  - Real world
tags:
  - temperature
  - weather
---
