---
title: Pin
categories:
  - Real world
tags:
  - pushpin
  - thumbtack
---
