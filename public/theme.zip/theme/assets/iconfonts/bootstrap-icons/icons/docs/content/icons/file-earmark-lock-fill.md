---
title: File earmark lock fill
categories:
  - Files and folders
tags:
  - lock
  - private
  - secure
---
