---
title: Mastodon
categories:
  - Social
tags:
---
