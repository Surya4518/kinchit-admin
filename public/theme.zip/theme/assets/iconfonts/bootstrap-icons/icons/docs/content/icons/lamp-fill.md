---
title: Lamp fill
categories:
  - Real world
tags:
  - light
  - lamp
---
