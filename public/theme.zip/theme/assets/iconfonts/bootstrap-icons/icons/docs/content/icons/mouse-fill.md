---
title: Mouse fill
categories:
  - Devices
tags:
  - mice
  - input
---
