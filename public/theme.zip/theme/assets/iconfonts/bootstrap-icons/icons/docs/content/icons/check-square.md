---
title: Check square
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
