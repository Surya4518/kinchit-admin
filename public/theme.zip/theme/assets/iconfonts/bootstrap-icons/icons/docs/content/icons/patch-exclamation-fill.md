---
title: Patch exclamation fill
categories:
  - Badges
tags:
  - excited
  - certified
aliases:
  - /icons/patch-exclamation-fll/
---
