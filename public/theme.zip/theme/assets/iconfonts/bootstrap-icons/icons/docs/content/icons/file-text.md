---
title: File text
categories:
  - Files and folders
tags:
  - doc
  - document
---
