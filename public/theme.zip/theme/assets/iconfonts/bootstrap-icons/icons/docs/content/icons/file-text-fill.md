---
title: File text fill
categories:
  - Files and folders
tags:
  - doc
  - document
---
