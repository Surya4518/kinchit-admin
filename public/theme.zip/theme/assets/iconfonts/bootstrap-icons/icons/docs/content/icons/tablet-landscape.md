---
title: Tablet landscape
categories:
  - Devices
tags:
  - mobile
---
