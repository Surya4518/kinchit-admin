---
title: Toggle off
categories:
  - Controls
tags:
  - toggle
  - switch
---
