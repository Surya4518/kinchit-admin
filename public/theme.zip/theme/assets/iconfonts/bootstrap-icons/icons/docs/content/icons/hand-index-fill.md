---
title: Hand index fill
categories:
  - Hands
tags:
  - hand
  - pointer
  - cursor
---
