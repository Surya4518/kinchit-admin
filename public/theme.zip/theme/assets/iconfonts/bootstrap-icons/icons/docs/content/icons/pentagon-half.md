---
title: Pentagon half
categories:
  - Shapes
tags:
  - shape
  - polygon
---
