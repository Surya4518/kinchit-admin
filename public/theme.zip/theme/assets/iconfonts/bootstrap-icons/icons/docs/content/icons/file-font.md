---
title: File font
categories:
  - Files and folders
tags:
  - ttf
  - otf
---
