---
title: Emoji wink fill
layout: icon
categories:
  - Emoji
tags:
  - emoticon
---
