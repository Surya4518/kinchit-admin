---
title: Emoji smile fill
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - happy
---
