---
title: File earmark PDF
categories:
  - Files and folders
tags:
  - doc
  - document
  - adobe
  - acrobat
---
