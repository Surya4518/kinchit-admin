---
title: Phone vibrate
categories:
  - Devices
tags:
  - mobile
  - telephone
  - haptic
---
