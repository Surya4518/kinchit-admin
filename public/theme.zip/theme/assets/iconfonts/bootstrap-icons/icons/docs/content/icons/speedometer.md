---
title: Speedometer
categories:
  - Real world
tags:
  - speed
  - tachometer
  - dashboard
---
