---
title: Percent
categories:
  - Typography
tags:
  - percentage
  - math
  - fraction
---
