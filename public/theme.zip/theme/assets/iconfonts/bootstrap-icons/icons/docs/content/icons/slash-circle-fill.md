---
title: Slash circle fill
categories:
  - Alerts, warnings, and signs
tags:
  - shape
  - stop
  - ban
  - no
---
