---
title: Thermometer high
categories:
  - Weather
tags:
  - temperature
  - weather
---
