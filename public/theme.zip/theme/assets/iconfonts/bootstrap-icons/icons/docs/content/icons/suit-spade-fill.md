---
title: Suit spade fill
categories:
  - Entertainment
tags:
  - card
  - cards
  - suit
  - deck
  - gambling
---
