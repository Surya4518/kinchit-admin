---
title: Hand index thumb fill
categories:
  - Hands
tags:
  - hand
  - pointer
  - cursor
---
