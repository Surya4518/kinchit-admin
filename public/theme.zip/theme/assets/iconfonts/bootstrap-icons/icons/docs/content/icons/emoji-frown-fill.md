---
title: Emoji frown fill
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - sad
---
