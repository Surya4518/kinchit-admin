---
title: Triangle
categories:
  - Shapes
tags:
  - shape
---
