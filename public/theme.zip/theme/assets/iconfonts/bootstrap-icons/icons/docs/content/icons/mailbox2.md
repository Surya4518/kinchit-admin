---
title: Mailbox2
categories:
  - Real world
tags:
  - post
  - postal
---
