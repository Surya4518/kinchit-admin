---
title: Lightning charge
categories:
  - Miscellaneous
tags:
  - weather
  - storm
  - thunder
  - bolt
---
