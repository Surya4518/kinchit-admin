---
title: Folder fill
categories:
  - Files and folders
tags:
  - directory
---
