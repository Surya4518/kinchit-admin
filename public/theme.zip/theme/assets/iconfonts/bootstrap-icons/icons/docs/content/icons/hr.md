---
title: HR
categories:
  - Typography
tags:
  - divider
  - horizonal-rule
---
