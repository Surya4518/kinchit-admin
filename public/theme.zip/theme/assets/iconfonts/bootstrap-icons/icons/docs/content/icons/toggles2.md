---
title: Toggles2
categories:
  - Controls
tags:
  - toggle
  - switch
---
