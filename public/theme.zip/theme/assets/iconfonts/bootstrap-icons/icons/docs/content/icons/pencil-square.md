---
title: Pencil square
categories:
  - Tools
tags:
  - edit
  - write
---
