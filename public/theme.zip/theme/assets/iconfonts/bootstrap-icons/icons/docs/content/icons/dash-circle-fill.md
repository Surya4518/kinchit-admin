---
title: Dash circle fill
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
