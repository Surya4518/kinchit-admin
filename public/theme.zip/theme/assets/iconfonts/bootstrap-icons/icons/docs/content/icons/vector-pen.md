---
title: Vector pen
categories:
  - Graphics
tags:
  - graphics
  - vector
  - pen
---
