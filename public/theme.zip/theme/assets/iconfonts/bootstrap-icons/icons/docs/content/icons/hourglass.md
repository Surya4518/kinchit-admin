---
title: Hourglass
categories:
  - Real world
tags:
  - time
  - history
  - wait
  - sand
---
