---
title: Shield check
categories:
  - Security
tags:
  - privacy
  - security
---
