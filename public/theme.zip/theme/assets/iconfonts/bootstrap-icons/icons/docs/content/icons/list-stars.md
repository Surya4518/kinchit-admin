---
title: List stars
categories:
  - Typography
tags:
  - text
  - type
  - starred
---
