---
title: Palette fill
categories:
  - Graphics
tags:
  - color
  - paint
  - fill
  - palette
---
