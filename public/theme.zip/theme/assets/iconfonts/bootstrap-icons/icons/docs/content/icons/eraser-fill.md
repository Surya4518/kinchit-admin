---
title: Eraser fill
categories:
  - Graphics
tags:
  - erase
  - remove
---
