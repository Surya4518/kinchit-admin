---
title: Phone landscape
categories:
  - Devices
tags:
  - mobile
  - telephone
---
