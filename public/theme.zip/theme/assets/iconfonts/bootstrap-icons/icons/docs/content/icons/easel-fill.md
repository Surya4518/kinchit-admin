---
title: Easel fill
categories:
  - Graphics
tags:
  - paint
  - draw
  - art
  - present
---
