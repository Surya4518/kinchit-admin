---
title: Palette
categories:
  - Graphics
tags:
  - color
  - paint
  - fill
  - palette
---
