---
title: Patch plus fill
categories:
  - Badges
tags:
aliases:
  - /icons/patch-plus-fll/
---
