---
title: Handbag fill
layout: icon
categories:
  - Real world
tags:
  - purse
  - tote
---
