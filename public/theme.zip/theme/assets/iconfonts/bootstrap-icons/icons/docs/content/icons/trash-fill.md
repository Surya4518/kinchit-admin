---
title: Trash fill
categories:
  - UI and keyboard
tags:
  - trash-can
  - garbage
  - delete
---
