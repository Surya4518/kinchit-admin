---
title: Square half fill
categories:
  - Shapes
tags:
  - shape
  - rectangle
---
