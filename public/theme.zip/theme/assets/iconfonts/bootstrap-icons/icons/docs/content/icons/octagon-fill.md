---
title: Octagon fill
categories:
  - Shapes
tags:
  - shape
  - polygon
---
