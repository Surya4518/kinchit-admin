---
title: Toggle2 on
categories:
  - Controls
tags:
  - toggle
  - switch
---
