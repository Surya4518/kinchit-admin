---
title: Save2
categories:
  - UI and keyboard
tags:
  - save
  - floppy
---
